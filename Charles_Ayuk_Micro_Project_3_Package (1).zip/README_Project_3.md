# ANA500 Micro-Project 3: Airline Arrival-Delay Regression
Charles Ayuk | November 7, 2026

This project follows the provided template through Step 5: Act. It compares ordinary least squares with linear support vector regression. Data preparation and random splits match Project 4 for comparability.

## Run
Use Python 3.11+ and install requirements.txt. Put airline.csv alongside the notebook or edit DATA_PATH. Run notebook cells in order. The notebook contains executed results and charts. The .py file contains the same commented code. The compiled code PDF includes code and outputs.

## Repository requirement remains pending
Your supplied link https://github.com/ChalesManyang is a profile URL. The currently connected GitHub account is Tabenock and has no write access to the ChalesManyang repositories. Connect ChalesManyang or grant the connected account access, then select or create a course repository. Upload the notebook and supporting files. Replace the pending repository text on the title slide with the actual repository URL and re-export the slide PDF.

## Findings
OLS and linear SVR have nearly identical test RMSE (10.03 minutes). Carrying departure delay forward gives the lowest test MAE (5.04 minutes). The survey has no flight/date identifiers, so this random passenger holdout cannot establish future-flight performance. All preprocessing uses training data only; SVR tuning and preferred-model selection use validation data before test evaluation.

The input airline.csv is supplied in this private download for reproducibility. Confirm redistribution rights before placing it in a public repository.
