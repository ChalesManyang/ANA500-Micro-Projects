# ANA500-Micro-Projects
Python data science projects for ANA500

Charles Ayuk | National University

Repository: https://github.com/ChalesManyang/ANA500-Micro-Projects

## Project files
| Micro-project | Methods | Final process step | Notebook |
| --- | --- | --- | --- |
| 1 | NumPy and Pandas preparation | Prepare | [Notebook 1](Micro_Project_1/Charles_Ayuk_Micro_Project_1.ipynb) |
| 2 | Matplotlib and Seaborn visualization | Report | [Notebook 2](Micro_Project_2/Charles_Ayuk_Micro_Project_2.ipynb) |
| 3 | Linear regression and linear SVR | Act | [Notebook 3](Micro_Project_3/Charles_Ayuk_Micro_Project_3.ipynb) |
| 4 | Deep feedforward neural-network regression | Act | [Notebook 4](Micro_Project_4/Charles_Ayuk_Micro_Project_4.ipynb) |

Each project folder contains its executed notebook, commented Python script, editable PowerPoint, slide PDF and compiled commented-code PDF. Project 4 uses three hidden layers. A recurrent model would require a meaningful sequence, which the supplied survey data does not provide.

## Run the analysis
1. Use Python 3.11 or later and create a virtual environment.
2. Install the pinned packages with `python -m pip install -r requirements.txt`.
3. Place the supplied `airline.csv` at the repository root, or alongside the selected notebook. Edit `DATA_PATH` for another location.
4. Open a notebook and run its cells in order.

The source is the user-supplied `airline.csv`: 129,880 passenger records and 25 original columns. The CSV is included in the private download packages. It is not republished in this repository. Obtain the same input from the course materials or the project author.

## Interpretation and limitations
Project 2 describes associations with satisfaction and does not establish causation. Projects 3 and 4 predict arrival-delay minutes using predictors available after departure. They exclude IDs, satisfaction and post-flight service ratings. They exclude 393 unknown arrival outcomes and use identical train/validation/test partitions (90,640 / 19,423 / 19,424 records, seed 42). Preprocessing uses training records only. Tuning uses validation records before held-out test evaluation.

The survey lacks dates, routes, weather and flight IDs. Random passenger splits cannot establish future-flight performance and may overstate generalization if travelers share a flight. Operational use requires validation on later flights.

The root-level slides uploaded earlier remain available. The project folders linked above contain the complete updated deliverables with the repository URL.
